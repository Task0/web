<?php
print_r($_REQUEST);
print_r($_SERVER);
?>
