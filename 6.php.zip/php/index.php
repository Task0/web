<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
 if ($_POST){
    file_put_contents('mikail.submit', json_encode($_POST)."\n", FILE_APPEND);
    header("Location: index.php"); /* Redirect browser */
    exit();
 }else{
   $lines = file_get_contents('mikail.submit');
   $lines = explode("\n", $lines);

   for($i = 0; $i < count($lines); $i++){
     $lines[$i] = json_decode($lines[$i], true);
   }
?>

<html>
  <head>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>

    <style>
      .error{
        color: red;
      }
    </style>
  </head>

  <body>
    <h1> Unesi raju u sistem</h1>
<div class="row">
  <div class="col-sm-3"></div>
  <div class="col-sm-6">
    <form id="hamdija-form" action="index.php" method="post">
      <div class="form-group">
        <label for="exampleInputEmail1">First Name</label>
        <input type="text" name="firstname" required class="form-control" placeholder="Enter First Name">
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Last Name</label>
        <input type="text" name="lastname" required class="form-control" placeholder="Enter Last Name">
      </div>
      <div class="form-group">
        <label>Amount</label>
        <input type="number" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" class="form-control" placeholder="Enter Email Address">
      </div>
      <button type="submit" class="btn btn-danger">Submit</button>
    </form>
  </div>
  <div class="col-sm-3"></div>

</div>


    <h1>RAJA U SISTEMU</h1>
    <table class="table table-hover">
      <tr>
        <th>Name</th>
        <th>Surname</th>
        <th>Amount</th>
        <th>Email</th>
      </tr>
      <?php
      foreach($lines as $line){
        if (!isset($line['firstname'])) continue;
      echo "
        <tr>
        <td>".$line['firstname']."</td>
        <td>".$line['lastname']."</td>
        <td>".$line['amount']."</td>
        <td>".$line['email']."</td>
      </tr>";
      }
       ?>
    </table>
  </body>

  <script>
    $("#hamdija-form").validate({
      rules: {
        lastname: {
          minlength: 2,
          maxlength: 5
        }
      },
      messages: {
        lastname: {
          required: "Hamdija de,der majke ti unesi prezime",
          minlength: "Unesi der koje slovo",
          maxlength: "Precero si hamdija"
        }
      },
      submitHandler: function(form) {
        if (confirm('Jesi fakat fakat fakat siguran da hoces da submitas????')){
          console.log(form);
          form.submit();
        }else{
          alert('Dobro ne moras odmah psovati');
        }
      }
    });
  </script>
</html>
<?php
}
?>
