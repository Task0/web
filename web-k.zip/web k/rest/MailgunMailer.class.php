<?php
require_once dirname(__FILE__).'/../vendor/autoload.php';

use Mailgun\Mailgun;

class MailgunMailer {
  private $api_key;
  private $domain;

  public function __construct($domain, $api_key){
    $this->domain = $domain;
    $this->api_key = $api_key;
  }

  public function send_email($from, $to, $cc, $bcc, $subject, $body, $attachments = null){
    $mg = Mailgun::create($this->api_key);

    $email_message = [
        'from'    => $from,
        'subject' => $subject,
        'html'    => $body
    ];

    if (isset($bcc) && $bcc != ''){
      $email_message['bcc'] = $bcc;
    }
    if (isset($cc) && $cc != ''){
      $email_message['cc'] = $cc;
    }
    if (isset($to) && $to != ''){
      $email_message['to'] = $to;
    }
    if (isset($attachments) && $attachments != ''){
      $email_message['attachment'] = $attachments;
    }

    return $mg->messages()->send($this->domain, $email_message);
  }
}
?>
