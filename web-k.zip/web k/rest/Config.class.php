<?php
class Config {

  const DB = [
    'host' => '',
    'username' => '',
    'password' => '',
    'db' => ''
  ];

  const JWT_SECRET = "secret";

}
?>
