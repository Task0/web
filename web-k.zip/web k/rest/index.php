<?php
require_once dirname(__FILE__).'/../vendor/autoload.php';
require_once dirname(__FILE__).'/Config.class.php';
require_once dirname(__FILE__).'/MailgunMailer.class.php';
require_once dirname(__FILE__).'/DB.class.php';

use \Firebase\JWT\JWT;

Flight::register('db', 'DB', [Config::DB]);

Flight::before('start', function(&$params, &$output){
  if (!(Flight::request()->url == '/login' && Flight::request()->method == 'POST')){

    $jwt = getallheaders()['mailer-jwt'];
    try {
      $decoded = (array)JWT::decode($jwt, Config::JWT_SECRET, ['HS256']);
      $decoded['user'] = (array)$decoded['user'];
      Flight::set('user', $decoded['user']);
    } catch (Exception $e) {
      Flight::halt(401, Flight::json(['message' => 'JWT token invalid']));
      die;
    }
  }
});

Flight::route('/', function(){
  echo 'hello world!';
  print_r(Flight::get('user'));
});

Flight::route('/hamo', function(){
  echo 'hello worldaaas!';
});

Flight::route('POST /login', function(){
  $request = Flight::request();

  $db_user = Flight::db()->get_client_by_email($request->data->email);
  if ($db_user){
    if ($db_user['password'] == $request->data->password){
      unset($db_user['password']);
      unset($db_user['mailgun_api_key']);
      unset($db_user['mailgun_domain']);

    $token = ["user" => $db_user, "iat" => time(), "exp" => time() + 60 /*2592000*/ /*30 days*/];
      $jwt = JWT::encode($token, Config::JWT_SECRET);

      $db_user['token'] = $jwt;
      Flight::json($db_user);
    }else{
      Flight::halt(400, Flight::json(['message' => 'Invalid password for email address '. $request->data->email]));
    }
  }else{
    Flight::halt(400, Flight::json(['message' => 'Invalid email address']));
  }
});

Flight::route('POST /mail/callback', function(){
  file_put_contents('hook.logs', print_r(Flight::request(), TRUE), FILE_APPEND);
});

Flight::route('POST /send', function(){
  $request = Flight::request();

  print_r($request);

  $attachments = NULL;
  foreach(@$request->files->attachments['name'] as $idx => $file){
    $tmp_name = $request->files->attachments['tmp_name'][$idx];
    $attachments[] = ['fileContent' => file_get_contents($tmp_name), 'filename' => $file];
  }

  //$mailgun = new MailgunMailer('', '');
  $mailgun = new MailgunMailer('', '');
  $response = $mailgun->send_email($request->data->from, 'dino@greenhosting.ba', NULL, implode(',', $request->data->recipients), $request->data->subject, $request->data->body, $attachments);

  print_r($response);
  echo 'email sent';
});

Flight::start();

?>
