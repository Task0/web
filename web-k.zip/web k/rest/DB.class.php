<?php
class DB{
    private $pdo;

    public function __construct($params){
        $this->pdo = new PDO("mysql:host=".$params['host'].";dbname=".$params['db'].";charset=utf8", $params['username'], $params['password']);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }

    private function execute($query, $params){
        $prepared_statement = $this->pdo->prepare($query);
        if ($params) {
            foreach ($params as $key => $param) {
                $prepared_statement->bindValue($key, $param);
            }
        }
        $prepared_statement->execute();
        return $prepared_statement;
    }
    public function query($query, $params){
        $prepared_statement = $this->execute($query, $params);
        return $prepared_statement->fetchAll();
    }
    public function query_single($query, $params){
        $result = $this->query($query, $params);
        return reset($result);
    }

    public function get_client_by_email($email){
      return $this->query_single("SELECT * FROM clients WHERE email =:email", [':email' => $email]);
    }

    public function get_all_clients(){
      return $this->query("SELECT c.id,
                           TRIM(CONCAT(c.lastname,' ', c.firstname)) name,
                           TRIM(c.companyname) companyname,
                           c.email,
                           GROUP_CONCAT(DISTINCT(d.domain) SEPARATOR ', ') AS domains,
                           GROUP_CONCAT(DISTINCT(h.domain) SEPARATOR ', ') AS hostings
                           FROM clients c LEFT OUTER JOIN
                           domains d ON c.id = d.userid LEFT OUTER JOIN
                           hostings h ON c.id = h.userid
                           WHERE c.status = 1
                           GROUP BY c.id", []);
    }


    public function get_client_by_id($id)
    {
        $statement = $this->pdo->prepare('SELECT * FROM clients WHERE id=:id');
        $statement->execute([':id' => $id]);

        print_r($statement->fetchAll(PDO::FETCH_ASSOC));

        //
    }
}
