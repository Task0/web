# mailer
simple application for sending emails in bulk


https://www.ibu.edu.ba
