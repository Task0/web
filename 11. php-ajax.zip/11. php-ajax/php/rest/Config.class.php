<?php
class Config{
  const DB = [
    'host' => 'srv10.domenice.net',
    'username' => 'biznet_users',
    'password' => 'C6!phtPve80i',
    'scheme' => 'biznet_users'
  ];
}
?>
