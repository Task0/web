<?php
require_once '../vendor/autoload.php';
require_once 'PersistanceManager.class.php';
require_once 'Config.class.php';

Flight::register('pm', 'PersistanceManager', [Config::DB]);

Flight::route('/', function(){
    echo 'hello world!';
});

Flight::route('GET /users', function(){
  $users = Flight::pm()->get_all_users();
  Flight::json($users);
});

Flight::route('GET /users/count', function(){
  sleep(4);
  $users = Flight::pm()->count_all_users();
  Flight::json($users);
});

Flight::route('DELETE /users/@id', function($id){
  Flight::pm()->delete_user($id);
});

Flight::route('POST /users', function(){
  $request = Flight::request();
  $user = [
    'first_name' => $request->data->first_name,
    'last_name' => $request->data->last_name,
    'email' => $request->data->email,
    'amount' => $request->data->amount
  ];
  $added_user = Flight::pm()->add_user($user);
  Flight::json($added_user);
});

Flight::start();

?>
